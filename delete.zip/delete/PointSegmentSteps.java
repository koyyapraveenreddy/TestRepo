package com.mastercard.lts.rewards.jbehave.steps;

import com.mastercard.lts.rewards.jbehave.pages.PointSegmentPage;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class PointSegmentSteps {
    @Autowired
    PointSegmentPage pointSegmentPage;

    @Given("Point segment page")
    public void givenPointSegmentPage() {
        pointSegmentPage.navigateToPointSegmentPage();
    }

    @When("Point segment name $name is entered")
    public void whenPointSegmentNameIsEntered(@Named("name") String name) {
        pointSegmentPage.getPointSegmentFormComponent().typePointSegmentNameInput(name);
    }

    @When("Non-existing point segment code $code is entered")
    public void whenNonExistingPointSegmentCodeIsEntered(@Named("code") String code) {
        pointSegmentPage.getPointSegmentFormComponent().typePointSegmentCodeInput(code);
    }

    @When("Existing point segment code $code is entered")
    public void whenExistingPointSegmentCodeIsEntered(@Named("code") String code) {
        pointSegmentPage.getPointSegmentFormComponent().typePointSegmentCodeInput(code);
    }

    @When("Begin Date $beginDate is entered")
    public void whenBeginDateIsEntered(@Named("beginDate") String beginDate) {
        pointSegmentPage.getPointSegmentFormComponent().typeBeginDate(beginDate);
    }

    @When("End Date $EndDate is entered")
    public void whenEndDateIsEntered(@Named("beginDate") String endDate) {
        pointSegmentPage.getPointSegmentFormComponent().typeEndDate(endDate);
    }

    @When("Add button is clicked")
    public void whenAddButtonIsClicked() throws Exception {
        pointSegmentPage.getPointSegmentFormComponent().clickOnAddButton();
    }

    @When("Delete button is clicked")
    public void whenDeleteButtonIsClicked() throws Exception {
        pointSegmentPage.getPointSegmentFormComponent().clickOnDeleteButton();
    }

    @When("Update button is clicked")
    public void whenUpdateButtonIsClicked() {
        pointSegmentPage.getPointSegmentFormComponent().clickOnUpdateButton();
    }

    @When("Reset Form button is clicked")
    public void whenResetFormButtonIsClicked() {
        pointSegmentPage.getPointSegmentFormComponent().clickOnResetFormButton();
    }

    @When("Point segment with point segment type code $code is clicked")
    public void whenPointSegmentIsClicked(@Named("code") String code) {
        pointSegmentPage.getPointSegmentListComponent().clickPointSegmentWithPointSegmentCode(code);
    }

    @Then("Delete button should be enabled")
    public void thenDeleteButtonShouldBeEnabled() throws Exception {
        Assert.assertTrue("Failed: Delete button should be enabled", pointSegmentPage.getPointSegmentFormComponent().isDeleteButtonEnabled());
    }

    @Then("Point segment Form should be populated with point segment with Point segment code $code")
    public void thenFormShouldBePopulatedWithPointSegment(@Named("code") String code) {
        Assert.assertTrue("Failed: Form should be populated with point segment", pointSegmentPage.getPointSegmentFormComponent().isPointSegmentSelected(code));
    }

    @Then("Point segment with point segment code $code should be deleted from Point Segment list")
    public void thenPointSegmentWithCodeShouldBeDeleted(@Named("code") String code) {
        Assert.assertFalse("Failed: Point Segment with code " + code + " should not be in point segment list", pointSegmentPage.getPointSegmentListComponent().isPointSegmentInList(code));
    }

    @Then("Point segment with point segment code $code should be added to the Point Segment list")
    public void thenPointSegmentWithCodeShouldBeAdded(@Named("code") String code) {
        Assert.assertTrue("Failed: Point Segment with code " + code + " should be in point segment list", pointSegmentPage.getPointSegmentListComponent().isPointSegmentInList(code));
    }

    @Then("Add button should be enabled")
    public void thenAddButtonShouldBeEnabled() {
        Assert.assertTrue("Failed: Button should have text 'Add'", "Add".equals(pointSegmentPage.getPointSegmentFormComponent().getAddButtonText()));
        Assert.assertTrue("Failed: Add button should be enabled", pointSegmentPage.getPointSegmentFormComponent().isAddButtonEnabled());
    }

    @Then("Add button should be disabled")
    public void thenAddButtonShouldBeDisabled() {
        Assert.assertTrue("Failed: Button should have text 'Add'", "Add".equals(pointSegmentPage.getPointSegmentFormComponent().getAddButtonText()));
        Assert.assertFalse("Failed: Add button should be disabled", pointSegmentPage.getPointSegmentFormComponent().isAddButtonEnabled());
    }

    @Then("Update button should be enabled")
    public void thenUpdateButtonShouldBeEnabled() {
        Assert.assertTrue("Failed: Button should have text 'Update'", "Update".equals(pointSegmentPage.getPointSegmentFormComponent().getUpdateButtonText()));
        Assert.assertTrue("Failed: Update button should be enabled", pointSegmentPage.getPointSegmentFormComponent().isUpdateButtonEnabled());
    }

    @Then("Update button should be disabled")
    public void thenUpdateButtonShouldBeDisabled() {
        Assert.assertTrue("Failed: Button should have text 'Update'", "Update".equals(pointSegmentPage.getPointSegmentFormComponent().getUpdateButtonText()));
        Assert.assertFalse("Failed: Update button should be disabled", pointSegmentPage.getPointSegmentFormComponent().isUpdateButtonEnabled());
    }

    @Then("Page title should be $pageTitle")
    public void thenPageTitleShouldbe(@Named("pageTitle") String pageTitle) {
        Assert.assertEquals("Failed: Page title shouhow ld be " + pageTitle, pageTitle, pointSegmentPage.getPageTitle());
    }

    @Then("Error message $message should be displayed")
    public void thenErrorMessageShouldBeDisplayed(@Named("message") String message) {
        Assert.assertTrue("Failed: error message, " + message + ", should be displayed", pointSegmentPage.getPointSegmentFormComponent().isErrorMsgDisplayed(message));
    }

    @Then("Alert message $message should be displayed")
    public void thenSuccessMessageShouldBeDisplayed(@Named("message") String message) {
        Assert.assertTrue("Failed: success message, " + message + ", should be displayed", pointSegmentPage.getPointSegmentFormComponent().isAlertMsgDisplayed(message));
    }

    @Then("Point segment name of point segment with code $code should be updated to $name")
    public void thenPointSegmentNameOfPointSegmentShouldBeUpdated(@Named("code") String code, @Named("name") String name) {
        Assert.assertEquals("Failed: Point segment name of point segment with code 321 should be " + name, name, pointSegmentPage.getPointSegmentListComponent().getPointSegmentNameByCode(code));
    }

    @Then("Point segment code input should be disabled")
    public void thenPointSegmentCodeInputShouldBeDisabled() {
        Assert.assertFalse("Failed: Point segment code input should be disabled", pointSegmentPage.getPointSegmentFormComponent().isPointSegmentCodeInputEnabled());
    }

    @Then("Reset Form button should be enabled")
    public void thenResetFormButtonShouldBeEnabled() {
        Assert.assertTrue("Failed: Reset Form Button should be enabled", pointSegmentPage.getPointSegmentFormComponent().isResetFormButtonEnabled());
    }

    @Then("Form should be cleared")
    public void thenFormShouldBeCleared() {
        Assert.assertEquals("Failed: Point segment code input should be empty", "", pointSegmentPage.getPointSegmentFormComponent().getPointSegmentCodeInputValue());
        Assert.assertEquals("Failed: Point segment name input should be empty", "", pointSegmentPage.getPointSegmentFormComponent().getPointSegmentNameInputValue());
        Assert.assertEquals("Failed: Begin date input should be empty", "", pointSegmentPage.getPointSegmentFormComponent().getBeginDateInputValue());
        Assert.assertEquals("Failed: End date input should be empty", "", pointSegmentPage.getPointSegmentFormComponent().getEndDateInputValue());
    }
}