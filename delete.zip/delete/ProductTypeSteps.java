package com.mastercard.lts.rewards.jbehave.steps;

import com.mastercard.lts.rewards.jbehave.pages.ProductTypesPage;
import org.jbehave.core.annotations.Given;
import org.jbehave.core.annotations.Named;
import org.jbehave.core.annotations.Then;
import org.jbehave.core.annotations.When;
import org.junit.Assert;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Created by e055756 on 5/12/2016.
 */
@Component
public class ProductTypeSteps {
    @Autowired
    ProductTypesPage productTypesPage;

    @Given("Product types page")
    public void givenProductTypesPage() {
        productTypesPage.navigateToProductTypesPage();
    }

    @When("Product type name $name is entered")
    public void whenProductTypeNameIsEntered(@Named("name") String name) {
        productTypesPage.getProductTypesFormComponent().typeProductTypeNameInput(name);
    }

    @When("Non-existing product type code $code is entered")
    public void whenNonExistingProductTypeCodeIsEntered(@Named("code") String code) {
        productTypesPage.getProductTypesFormComponent().typeProductTypeCodeInput(code);
    }

    @When("Existing product type code $code is entered")
    public void whenExistingProductTypeCodeIsEntered(@Named("code") String code) {
        productTypesPage.getProductTypesFormComponent().typeProductTypeCodeInput(code);
    }

    @When("Begin Date $beginDate is entered")
    public void whenBeginDateIsEntered(@Named("beginDate") String beginDate) {
        productTypesPage.getProductTypesFormComponent().typeBeginDate(beginDate);
    }

    @When("End Date $EndDate is entered")
    public void whenEndDateIsEntered(@Named("beginDate") String endDate) {
        productTypesPage.getProductTypesFormComponent().typeEndDate(endDate);
    }

    @When("Add button is clicked")
    public void whenAddButtonIsClicked() throws Exception {
        productTypesPage.getProductTypesFormComponent().clickOnAddButton();
    }

    @When("Delete button is clicked")
    public void whenDeleteButtonIsClicked() throws Exception {
        productTypesPage.getProductTypesFormComponent().clickOnDeleteButton();
    }

    @When("Update button is clicked")
    public void whenUpdateButtonIsClicked() {
        productTypesPage.getProductTypesFormComponent().clickOnUpdateButton();
    }

    @When("Reset Form button is clicked")
    public void whenResetFormButtonIsClicked() {
        productTypesPage.getProductTypesFormComponent().clickOnResetFormButton();
    }

    @When("Product type with product type code $code is clicked")
    public void whenProductTypeIsClicked(@Named("code") String code) {
        productTypesPage.getProductTypesListComponent().clickProductTypeWithProductTypeCode(code);
    }

    @Then("Delete button should be enabled")
    public void thenDeleteButtonShouldBeEnabled() throws Exception {
        Assert.assertTrue("Failed: Delete button should be enabled", productTypesPage.getProductTypesFormComponent().isDeleteButtonEnabled());
    }

    @Then("Product type Form should be populated with product type with Product type code $code")
    public void thenFormShouldBePopulatedWithProductType(@Named("code") String code) {
        Assert.assertTrue("Failed: Form should be populated with product type", productTypesPage.getProductTypesFormComponent().isProductTypeSelected(code));
    }

    @Then("Product type with product type code $code should be deleted from Product Types list")
    public void thenProductTypeWithCodeShouldBeDeleted(@Named("code") String code) {
        Assert.assertFalse("Failed: Product Type with code " + code + " should not be in product types list", productTypesPage.getProductTypesListComponent().isProductTypeInList(code));
    }

    @Then("Product type with product type code $code should be added to the Product Types list")
    public void thenProductTypeWithCodeShouldBeAdded(@Named("code") String code) {
        Assert.assertTrue("Failed: Product Type with code " + code + " should be in product types list", productTypesPage.getProductTypesListComponent().isProductTypeInList(code));
    }

    @Then("Add button should be enabled")
    public void thenAddButtonShouldBeEnabled() {
        Assert.assertTrue("Failed: Button should have text 'Add'", "Add".equals(productTypesPage.getProductTypesFormComponent().getAddButtonText()));
        Assert.assertTrue("Failed: Add button should be enabled", productTypesPage.getProductTypesFormComponent().isAddButtonEnabled());
    }

    @Then("Add button should be disabled")
    public void thenAddbuttonShouldBeDisabled() {
        Assert.assertTrue("Failed: Button should have text 'Add'", "Add".equals(productTypesPage.getProductTypesFormComponent().getAddButtonText()));
        Assert.assertFalse("Failed: Add button should be disabled", productTypesPage.getProductTypesFormComponent().isAddButtonEnabled());
    }

    @Then("Update button should be enabled")
    public void thenUpdateButtonShouldBeEnabled() {
        Assert.assertTrue("Failed: Button should have text 'Update'", "Update".equals(productTypesPage.getProductTypesFormComponent().getAddButtonText()));
        Assert.assertTrue("Failed: Update button should be enabled", productTypesPage.getProductTypesFormComponent().isAddButtonEnabled());
    }

    @Then("Update button should be disabled")
    public void thenUpdateButtonShouldBeDisabled() {
        Assert.assertTrue("Failed: Button should have text 'Update'", "Update".equals(productTypesPage.getProductTypesFormComponent().getAddButtonText()));
        Assert.assertFalse("Failed: Update button should be disabled", productTypesPage.getProductTypesFormComponent().isAddButtonEnabled());
    }

    @Then("Page title should be $pageTitle")
    public void thenPageTitleShouldbe(@Named("pageTitle") String pageTitle) {
        Assert.assertEquals("Failed: Page title shouhow ld be " + pageTitle, pageTitle, productTypesPage.getPageTitle());
    }

    @Then("Error message $message should be displayed")
    public void thenErrorMessageShouldBeDisplayed(@Named("message") String message) {
        Assert.assertTrue("Failed: error message, " + message + ", should be displayed", productTypesPage.getProductTypesFormComponent().isErrorMsgDisplayed(message));
    }

    @Then("Alert message $message should be displayed")
    public void thenSuccessMessageShouldBeDisplayed(@Named("message") String message) {
        Assert.assertTrue("Failed: success message, " + message + ", should be displayed", productTypesPage.getProductTypesFormComponent().isAlertMsgDisplayed(message));
    }

    @Then("Product type name of product type with code $code should be updated to $name")
    public void thenProductTypeNameOfProductTypeShouldBeUpdated(@Named("code") String code, @Named("name") String name) {
        Assert.assertEquals("Failed: Product type name of product type with code 321 should be " + name, name, productTypesPage.getProductTypesListComponent().getProductTypeNameByCode(code));
    }

    @Then("Product type code input should be disabled")
    public void thenProductTypeCodeInputShouldBeDisabled() {
        Assert.assertFalse("Failed: Product type code input should be disabled", productTypesPage.getProductTypesFormComponent().isProductTypeCodeInputEnabled());
    }

    @Then("Reset Form button should be enabled")
    public void thenResetFormButtonShouldBeEnabled() {
        Assert.assertTrue("Failed: Reset Form Button should be enabled", productTypesPage.getProductTypesFormComponent().isResetFormButtonEnabled());
    }

    @Then("Form should be cleared")
    public void thenFormShouldBeCleared() {
        Assert.assertEquals("Failed: Product type code input should be empty", "", productTypesPage.getProductTypesFormComponent().getProductTypeCodeInputValue());
        Assert.assertEquals("Failed: Product type name input should be empty", "", productTypesPage.getProductTypesFormComponent().getProductTypeNameInputValue());
        Assert.assertEquals("Failed: Begin date input should be empty", "", productTypesPage.getProductTypesFormComponent().getBeginDateInputValue());
        Assert.assertEquals("Failed: End date input should be empty", "", productTypesPage.getProductTypesFormComponent().getEndDateInputValue());
    }


}
